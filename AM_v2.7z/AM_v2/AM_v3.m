fs = 48000;
deltaT = 1/fs;
T = 0.5;
t = (0:deltaT:T-deltaT);
f1 = 50;
f2 = 100;
f3 = 150;
f4 = 125;
t1 = 0.3*sin(2*pi*f1*t);
t2 = 0.2*sin(2*pi*f2*t);
t3 = 0.15*sin(2*pi*f3*t);
t4 = 0.15*sin(2*pi*f4*t);
additiveSum = t1 + t2 + t3 + t4;
plot(t,additiveSum);
title('Summation')
figure;
quan = quantizer([16,15]);
bin1=num2bin(quan,t1);
bin2=num2bin(quan,t2);
bin3=num2bin(quan,t3);
bin4=num2bin(quan,t4);

% need to add the file and array and store it into c %
quan2 = quantizer([24,23]);
output = bin2num(quan2, output1);
channelStream = transpose(cell2mat(output));
plot(t,channelStream);
title('Gain multiplied summation')
audiowrite('output.wav',channelStream, fs);